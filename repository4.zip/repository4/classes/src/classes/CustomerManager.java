package classes;

public class CustomerManager {

	public void Add() {
		System.out.println("müşteri eklendi");
	}
	public void Remove() {
		System.out.println("müşteri silindi");
	}
	public void Update() {
		System.out.println("müşteri güncellendi");
	}
}
