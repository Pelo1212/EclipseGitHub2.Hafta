package methodOverloading;

public class Main {

	public static void main(String[] args) {
	DortIslem dortIslem=new DortIslem();
	System.out.println(dortIslem.topla(58, 15));
	dortIslem.topla(12, 13, 16);

	}

}
