package classesWithAttributes;

public class ProductManager {

	public void Add (Product product){//manager classımda ekle metodunun içine ürünümü yazdım parametre olarak.
		//JDBS kodları yazarak bu productı veri tabanına kaydedicez.
		System.out.println("ürün eklendi");
	}
}
