package inheritance;

public class CustomerManager extends PersonManager {

}
