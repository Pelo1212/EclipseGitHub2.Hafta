package inheritance;

public class Main {

	public static void main(String[] args) {
		Customer customer=new Customer();
		Employee employee=new Employee();
		
		CustomerManager customerManager = new CustomerManager();
		EmployeeManager employeeManager = new EmployeeManager();
		
		
		//employeeManager. dediğimizde 3 method birden seçebilicez PersonManagerı extends ettiğimiz için 

	}

}
