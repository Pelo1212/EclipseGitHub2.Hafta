package inheritance;

public class Person {
	int id;
	String firstName;
	String lastName;
	int age;

}
