package inheritance;

public class PersonManager {
	public void list() {
		System.out.println("listelendi");
	}

	public void Add() {
		System.out.println("eklendi");
	}
  

}
