package inheritance;

public class EmployeeManager extends PersonManager {

	
	public void bestEmployee() {
		System.out.println("ayın elamanı seçildi");
	}
}
