package inheritanceDemo;

public class TarimKrediManager extends BaseKrediManager {

}
