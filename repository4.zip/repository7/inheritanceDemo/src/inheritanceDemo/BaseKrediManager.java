package inheritanceDemo;

public class BaseKrediManager {
	public void hesapla() {
		System.out.println("kredi hesaplandı");
	}

}
