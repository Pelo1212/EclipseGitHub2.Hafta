package inheritanceDemo;

public class AskerKrediManager extends BaseKrediManager{

}
