package inheritanceDemo;

public class OgretmenKrediManager extends BaseKrediManager {

}
