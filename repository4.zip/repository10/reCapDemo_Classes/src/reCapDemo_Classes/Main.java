package reCapDemo_Classes;

public class Main {

	public static void main(String[] args) {
		DortIslem dortIslem=new DortIslem(); //classımı new'ledim.
	    int sonuc =dortIslem.Topla(5, 9);
	    System.out.println(sonuc);
	}

}
