package reCapDemo_Classes;

public class DortIslem {

	public int Topla(int sayi1, int sayi2) {
		return sayi1+sayi2;
	}
	public int Cıkar(int sayi1, int sayi2) {
		return sayi1+sayi2;
	}
	public int Carp(int sayi1, int sayi2) {
		return sayi1+sayi2;
	}
	public int Bol(int sayi1, int sayi2) {
		return sayi1+sayi2;
	}
}
